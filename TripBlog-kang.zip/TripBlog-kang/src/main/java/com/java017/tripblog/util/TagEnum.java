package com.java017.tripblog.util;
    public enum TagEnum {
        咖啡,紅茶,拉麵,蛋糕,餅乾,義大利麵,汽水
    }

